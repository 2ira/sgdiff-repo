# Part 2 submission package

This package contains the completed CN, GCN, and SGDiff Part 2 report and slides for Cora, CiteSeer, and PubMed.

The final aligned grid contains 882 evaluated cells: 3 datasets, 7 configurations, 3 seeds, and 14 test conditions. All graph hashes matched the pinned evaluator assets.

## Contents

- `report/main.tex`: editable report source.
- `report/references.bib`: report bibliography.
- `report/figures/` and `report/generated/`: generated figures and tables used by the report.
- `report/part2_report_rendered.pdf`: rendered eight-page report.
- `slides/part2_slides_editable_pptx.url`: shortcut to the editable live slide deck; use the viewer's download action to export PPTX.
- `slides/part2_slides_rendered.pdf`: rendered nine-slide deck.
- `slides/slide-01.png` through `slide-09.png`: per-slide previews.
- `slides/part2_slides_outline.md`: editable content outline.

The NCNC comparison remains limited to Cora and CiteSeer because the pinned team reference extract contains only those datasets.
