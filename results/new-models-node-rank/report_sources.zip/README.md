# Standalone Chinese TeX report

All numerical tables are embedded in report.tex. All 17 PDF figures and
references.bib are included. No model, GPU, dataset or network API is needed.

Compile with Tectonic 0.17.0:

    tectonic report.tex

On first use Tectonic downloads its TeX/CTeX/Fandol dependencies. Once cached,
compilation works offline. Alternatively use a recent TeX Live installation:

    xelatex report.tex
    bibtex report
    xelatex report.tex
    xelatex report.tex

The Chinese fontset is Fandol. Source result tables and CPU replay are in the
repository results/new-models-node-rank and experiments/new_models_rank.
